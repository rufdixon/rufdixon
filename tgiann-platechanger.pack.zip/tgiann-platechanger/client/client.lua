myFramework = nil
Citizen.CreateThread(function() 
    if framework == "esx" then
        while myFramework == nil do
            TriggerEvent('esx:getSharedObject', function(obj) myFramework = obj end)
            Citizen.Wait(0)
        end
    end
end)

local vehicle = 0

Citizen.CreateThread(function()
    while true do
        local time = 1000
        local playerPed = PlayerPedId()
        local playerCoord = GetEntityCoords(playerPed)
        local dist = #(playerCoord - changeCoord)
        if dist < 15 then
            time = 1
            DrawMarker(21, changeCoord, 0, 0, 0, 0, 0, 0, 0.301, 0.301, 0.3001, 0, 255, 50, 200, 0, 1, 0, 0)
            if dist < 5 then
                local text = ""
                if dist < 2 then
                    text = "[E] "
                    if IsControlJustReleased(0, 38) then
                        if IsPedInAnyVehicle(playerPed) then
                            SetNuiFocus(true, true)
                            vehicle = GetVehiclePedIsIn(playerPed) 
                            SendNUIMessage({ type = 'open', plate = trimText(GetVehicleNumberPlateText(vehicle)) })
                        else
                            showNotification("You have to be in the vehicle!") 
                        end
                    end
                end
                if framework then
                    DrawText3D(changeCoord.x,changeCoord.y,changeCoord.z+0.5, text.."Edit License Plate ["..reqMoney.."$]")
                else
                    DrawText3D(changeCoord.x,changeCoord.y,changeCoord.z+0.5, text.."Edit License Plate [FREE]")
                end
            end
        end
        Citizen.Wait(time)
    end
end)

RegisterNUICallback('close', function(data)
    SetNuiFocus(false, false)
end)

RegisterNUICallback('save', function(data, cb)
    local waitCb = nil
    local oldPlate = trimText(GetVehicleNumberPlateText(vehicle))
    TriggerCallback("tgiann-platechanger:checkPlate", function(result)
        waitCb = result
    end, data.plate)
    while waitCb == nil do Citizen.Wait(10) end
    if waitCb then 
        if framework then
            local vehProp = ""
            if framework == "esx" then
                vehProp = myFramework.Game.GetVehicleProperties(vehicle)
                vehProp.plate = data.plate
            end
            TriggerServerEvent("tgiann-platechanger:setNewPlate", oldPlate, data.plate, vehProp)
        end
        SetVehicleNumberPlateText(vehicle, data.plate)
    end
    cb(waitCb)
end)

RegisterNetEvent("client:notif")
AddEventHandler("client:notif",function(msg)
    showNotification(msg)
end)

function showNotification(msg)
	BeginTextCommandThefeedPost('STRING')
	AddTextComponentSubstringPlayerName(msg)
	EndTextCommandThefeedPostTicker(0,1)
end

function DrawText3D(x, y, z, text)
	SetTextScale(0.30, 0.30)
    SetTextFont(0)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(true)
    AddTextComponentString(text)
    SetDrawOrigin(x,y,z, 0)
    DrawText(0.0, 0.0)
    local factor = (string.len(text)) / 250
    DrawRect(0.0, 0.0+0.0125, 0.017+ factor, 0.03, 0, 0, 0, 75)
    ClearDrawOrigin()
end

function trimText(value)
	if value then
		return (string.gsub(value, "^%s*(.-)%s*$", "%1"))
	else
		return nil
	end
end