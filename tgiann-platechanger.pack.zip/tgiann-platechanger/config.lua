reqMoney = 5000
changeCoord = vector3(146.53, 320.62, 111.87)
framework = "esx" --        false      -     "esx"     -     "qb"
--if you are not using esx delete lines 9 and 10 in fxmanifest.lua