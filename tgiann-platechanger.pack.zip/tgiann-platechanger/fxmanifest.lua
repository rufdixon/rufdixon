fx_version 'cerulean'
game 'gta5'

lua54 'yes'

escrow_ignore {
	'config.lua',
	'client/client.lua',
	'server/server.lua',
}

shared_script "config.lua"

client_scripts {
	'client/*.lua'
}

server_scripts {
	'@async/async.lua',
	'@mysql-async/lib/MySQL.lua',
	'server/*.lua'
}

ui_page 'ui/index.html'

files {
	'ui/index.html',
	'ui/css/*.css',
	'ui/js/*.js',
}
dependency '/assetpacks'