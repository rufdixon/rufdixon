const alphabet = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
const numbers = ["1","2","3","4","5","6","7","8","9","0"]

window.addEventListener('message', (event) => {
    if (event.data.type === 'open') {
        $(".changer-container").fadeIn();
        
        for (let i = 0; i < 8; i++) {
            const text = event.data.plate[i]
            $("#changer-"+(i+1)).data("type", setDataType(text))
            $("#changer-"+(i+1)).children(".changer-input-text").html(text)
        }
    }
});

function setDataType(text) {
    let type = "alphabet"
    for (let i = 0; i < numbers.length; i++) {
        if (numbers[i] == text) {
            type = "numbers"
            break;
        }
    }
    return type
};

$(".changer-input-arrow-top").on("click", function() {
    setNewValue($(this).parent(".changer-input").attr('id'), $(this).parent(".changer-input").data("type"), true)
});

$(".changer-input-arrow-bottom").on("click", function() {
    setNewValue($(this).parent(".changer-input").attr('id'), $(this).parent(".changer-input").data("type"), false)
});

$("#cancel").on("click", function() {
    $(".changer-container").fadeOut();
    $.post('https://tgiann-platechanger/close', JSON.stringify({}));
});

$("#save").on("click", function() {
    let plateText = ""
    for (let i = 0; i < 8; i++) {
        plateText = plateText + $("#changer-"+(i+1)).children(".changer-input-text").html()
    }
    $.post('https://tgiann-platechanger/save', JSON.stringify({plate:plateText}), function(close) {
        if (close) {
            $(".changer-container").fadeOut();
            $.post('https://tgiann-platechanger/close', JSON.stringify({}));
        }
    });
});

function setNewValue(id, type, up) {
    const input = $("#"+id).children(".changer-input-text")
    const val = input.html()
    let obje = alphabet;
    let newVal = ""
    if (type == "numbers") { obje = numbers };
    for (let i = 0; i < obje.length; i++) {
        if (up) {
            if (obje[i] == val) {
                if ( i+1 == obje.length ) {
                    newVal = obje[0]
                    break
                } else {
                    newVal = obje[i+1]
                    break
                }
            }
        } else {
            if (obje[i] == val) {
                if ( i == 0 ) {
                    newVal = obje[obje.length-1]
                    break
                } else {
                    newVal = obje[i-1]
                    break
                }
            }
        }
    }
    input.html(newVal)
};