local myFramework = nil
if framework == "esx" then
	TriggerEvent('esx:getSharedObject', function(obj) myFramework = obj end) 
elseif framework == "qb" then
	myFramework = exports['qb-core']:GetCoreObject()
end

CreateCallback("tgiann-platechanger:checkPlate", function(source, cb, plate)
    local src = source
    if framework == "esx" then
        local xPlayer = myFramework.GetPlayerFromId(src)
        if xPlayer then
            if xPlayer.getAccount("bank").money >= reqMoney then
                MySQL.Async.fetchAll("SELECT plate FROM owned_vehicles WHERE plate = @plate", {
                    ["@plate"] = plate
                }, function (result)
                    if result[1] then
                        TriggerClientEvent("client:notif", src, "This license plate belongs to someone else!", "error")
                        cb(false)
                    else
                        xPlayer.removeAccountMoney("bank", reqMoney)
                        cb(true)
                    end
                end)
            else
                TriggerClientEvent("client:notif", src, "you don't have enough money on bank account!")
            end
        end
    elseif framework == "qb" then
        local xPlayer = myFramework.Functions.GetPlayer(src)
        if xPlayer.PlayerData.money.bank >= reqMoney then
            exports.oxmysql:execute("SELECT plate FROM player_vehicles WHERE plate = @plate", {
                ["@plate"] = plate
            }, function (result)
                if result[1] then
                    TriggerClientEvent("client:notif", src, "This license plate belongs to someone else!", "error")
                    cb(false)
                else
                    xPlayer.Functions.RemoveMoney('bank', reqMoney)
                    cb(true)
                end
            end)
        else
            TriggerClientEvent("client:notif", src, "you don't have enough money on bank account!")
        end
    else
        cb(true)
    end
end)

RegisterServerEvent('tgiann-platechanger:setNewPlate')
AddEventHandler('tgiann-platechanger:setNewPlate', function(old, new, prop)
    if framework == "esx" then
        MySQL.Async.fetchAll("UPDATE owned_vehicles SET plate=@plate, vehicle=@vehicle WHERE plate = @oldPlate", {
            ['@oldPlate'] = old,
            ['@plate'] = new,
            ['@vehicle'] = json.encode(prop)
        })
    elseif framework == "qb" then
        exports.oxmysql:execute("UPDATE player_vehicles SET plate=@plate WHERE plate = @oldPlate", {
            ['@oldPlate'] = old,
            ['@plate'] = new,
        })
    end
end)